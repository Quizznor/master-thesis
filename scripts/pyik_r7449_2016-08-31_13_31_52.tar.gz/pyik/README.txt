This is a copy of the pyik repository as it was on the devel-ik.fzk.de
repository on August 31, 2016 at 13:31:52. The redacted output of svn status
was

Path: .
Working Copy Root Path: ***********/pyik
URL: https://devel-ik.fzk.de/svn/misc/PythonTools/pyik
Relative URL: ^/PythonTools/pyik
Repository Root: https://devel-ik.fzk.de/svn/misc
Repository UUID: c8e3f56a-07a3-11dd-90df-b1451ff9f51e
Revision: 7449
Node Kind: directory
Schedule: normal
Last Changed Author: bridgeman
Last Changed Rev: 7350
Last Changed Date: 2016-08-31 13:31:52 +0200 (Wed, 31 Aug 2016)

Note that pyik development continue{s,d}, hosted here:

https://github.com/HDembinski/pyik

but without the adst module specific to Auger. It is possible that a 
more recent version of the adst module exists than that in this archive.